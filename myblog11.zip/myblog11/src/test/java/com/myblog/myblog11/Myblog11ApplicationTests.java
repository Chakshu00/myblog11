package com.myblog.myblog11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myblog11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
